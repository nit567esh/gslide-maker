from .mailreport import makeoutput
from .mailreport import sendmail